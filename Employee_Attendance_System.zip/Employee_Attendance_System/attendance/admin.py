from django.contrib import admin
from .models import EmployeeProfile, Attendance, LeaveRequest

@admin.register(EmployeeProfile)
class EmployeeProfileAdmin(admin.ModelAdmin):
    list_display = ("employee_id", "user", "department", "designation")
    search_fields = ("employee_id", "user__username")

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("employee", "date", "check_in", "check_out", "status")
    list_filter = ("date", "status")
    search_fields = ("employee__username",)

@admin.register(LeaveRequest)
class LeaveRequestAdmin(admin.ModelAdmin):
    list_display = ("employee", "start_date", "end_date", "status", "applied_at")
    list_filter = ("status",)
    actions = ["approve_requests", "reject_requests"]
    @admin.action(description="Approve selected leave requests")
    def approve_requests(self, request, queryset):
        from django.utils import timezone
        queryset.update(status="APPROVED", reviewed_at=timezone.now())
    @admin.action(description="Reject selected leave requests")
    def reject_requests(self, request, queryset):
        from django.utils import timezone
        queryset.update(status="REJECTED", reviewed_at=timezone.now())
