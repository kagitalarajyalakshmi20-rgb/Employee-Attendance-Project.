from django.urls import path
from django.contrib.auth.views import LogoutView
from .views import EmployeeLoginView, dashboard, attendance_page, leave_request, monthly_report

urlpatterns = [
    path("", dashboard, name="dashboard"),
    path("login/", EmployeeLoginView.as_view(), name="login"),
    path("logout/", LogoutView.as_view(), name="logout"),
    path("attendance/", attendance_page, name="attendance"),
    path("leave/", leave_request, name="leave_request"),
    path("reports/", monthly_report, name="monthly_report"),
]
