from django.test import TestCase
# Add automated tests here as you extend the project.
