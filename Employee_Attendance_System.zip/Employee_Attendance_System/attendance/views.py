import calendar
from datetime import date
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.shortcuts import render, redirect
from django.utils import timezone
from django.db.models import Count
from .models import Attendance, LeaveRequest

class EmployeeLoginView(LoginView):
    template_name = "login.html"

@login_required
def dashboard(request):
    today = timezone.localdate()
    attendance_today = Attendance.objects.filter(employee=request.user, date=today).first()
    recent_attendance = Attendance.objects.filter(employee=request.user)[:7]
    leaves = LeaveRequest.objects.filter(employee=request.user)[:5]
    return render(request, "dashboard.html", {
        "attendance_today": attendance_today, "recent_attendance": recent_attendance, "leaves": leaves
    })

@login_required
def attendance_page(request):
    today = timezone.localdate()
    record = Attendance.objects.filter(employee=request.user, date=today).first()
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "check_in":
            if record and record.check_in:
                messages.info(request, "You have already checked in today.")
            else:
                record, _ = Attendance.objects.get_or_create(employee=request.user, date=today)
                record.check_in = timezone.localtime().time().replace(microsecond=0)
                record.status = "PRESENT"
                record.save()
                messages.success(request, "Check-in recorded.")
        elif action == "check_out":
            if not record or not record.check_in:
                messages.error(request, "Please check in before checking out.")
            elif record.check_out:
                messages.info(request, "You have already checked out today.")
            else:
                record.check_out = timezone.localtime().time().replace(microsecond=0)
                record.save()
                messages.success(request, "Check-out recorded.")
        return redirect("attendance")
    history = Attendance.objects.filter(employee=request.user)[:30]
    return render(request, "attendance.html", {"record": record, "history": history})

@login_required
def leave_request(request):
    if request.method == "POST":
        start = request.POST.get("start_date")
        end = request.POST.get("end_date")
        reason = request.POST.get("reason", "").strip()
        try:
            start_date = date.fromisoformat(start)
            end_date = date.fromisoformat(end)
            if end_date < start_date:
                raise ValueError
            if not reason:
                messages.error(request, "Please enter a reason.")
            else:
                LeaveRequest.objects.create(employee=request.user, start_date=start_date, end_date=end_date, reason=reason)
                messages.success(request, "Leave request submitted.")
                return redirect("leave_request")
        except (TypeError, ValueError):
            messages.error(request, "Please enter valid dates. End date must not be before start date.")
    requests = LeaveRequest.objects.filter(employee=request.user)
    return render(request, "leave_request.html", {"leave_requests": requests})

@login_required
def monthly_report(request):
    today = timezone.localdate()
    try:
        month = int(request.GET.get("month", today.month))
        year = int(request.GET.get("year", today.year))
        if month not in range(1, 13) or year not in range(2000, 2101):
            raise ValueError
    except ValueError:
        month, year = today.month, today.year
    records = Attendance.objects.filter(employee=request.user, date__year=year, date__month=month)
    summary = records.values("status").annotate(total=Count("id"))
    counts = {item["status"]: item["total"] for item in summary}
    leave_count = LeaveRequest.objects.filter(
        employee=request.user, status="APPROVED",
        start_date__year=year, start_date__month=month
    ).count()
    return render(request, "monthly_report.html", {
        "records": records, "month": month, "year": year,
        "month_name": calendar.month_name[month],
        "present": counts.get("PRESENT", 0), "late": counts.get("LATE", 0),
        "absent": counts.get("ABSENT", 0), "approved_leaves": leave_count,\n        "months": [(i, calendar.month_name[i]) for i in range(1, 13)],
    })
