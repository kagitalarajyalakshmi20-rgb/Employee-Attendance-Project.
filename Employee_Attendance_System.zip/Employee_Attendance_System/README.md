# Employee Attendance Management System

A starter Django + MySQL project with employee login, daily check-in/check-out, leave requests, admin approval, and monthly reports.

## Requirements
- Python 3.10 or newer
- MySQL Server (for example, MySQL Community Server)
- VS Code (optional)

## 1. Extract and open
Extract `Employee_Attendance_System.zip`. Open the extracted `Employee_Attendance_System` folder in VS Code.

## 2. Create and activate a virtual environment (Windows PowerShell)
```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
```
If PowerShell blocks activation, run this once in the same terminal:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\venv\Scripts\Activate.ps1
```

## 3. Install packages
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```
`mysqlclient` needs a compatible MySQL client build environment on some Windows installations. If installation fails, install the MySQL Connector/C build prerequisites or ask for help with the exact error.

## 4. Create the MySQL database
Open MySQL Workbench or MySQL command line and run:
```sql
CREATE DATABASE employee_attendance_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Open `attendance_project/settings.py` and update `USER` and `PASSWORD` in `DATABASES` to match your local MySQL account.

## 5. Create database tables
In the VS Code terminal (with venv active):
```powershell
python manage.py makemigrations attendance
python manage.py migrate
```

## 6. Create an admin account
```powershell
python manage.py createsuperuser
```
Follow the prompts to create a username and password. This account can access the admin area and manage employees and leave approvals.

## 7. Start the website
```powershell
python manage.py runserver
```
Open http://127.0.0.1:8000/ in your browser. Log in with the superuser account you created.

## 8. Add employee accounts
Open http://127.0.0.1:8000/admin/ and log in as the superuser.
- Under **Users**, add an employee username and password.
- Under **Employee profiles**, create a profile for that user and enter a unique employee ID.
- Employees can then log in at the main website.
- Admin can review and approve/reject leave requests under **Leave requests**.

## Notes
- This is an educational starter project. It does not include production security hardening, payroll, automatic absence marking, or downloadable Excel/PDF reports.
- The monthly report counts attendance records and approved leave requests whose start date falls in the selected month.
- For a real deployment, set `DEBUG = False`, use a strong secret key, configure allowed hosts, HTTPS, backups, and secure credentials.
